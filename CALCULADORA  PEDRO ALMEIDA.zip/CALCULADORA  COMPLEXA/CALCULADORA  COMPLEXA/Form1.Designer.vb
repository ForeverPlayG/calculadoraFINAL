﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        TxtBox = New TextBox()
        Btt1 = New Button()
        Btt2 = New Button()
        Btt5 = New Button()
        Btt4 = New Button()
        Btt3 = New Button()
        Btt8 = New Button()
        Btt6 = New Button()
        Btt0 = New Button()
        Btt9 = New Button()
        Btt7 = New Button()
        BttVEZES = New Button()
        BttIGUAL = New Button()
        BttMAIS = New Button()
        BttSQR = New Button()
        BttMENOS = New Button()
        BttDIVIDIR = New Button()
        BttC = New Button()
        BttPONTO = New Button()
        BttELEVADO = New Button()
        BttSIN = New Button()
        BttCOS = New Button()
        BttPI = New Button()
        BttFR = New Button()
        BttSQRELE = New Button()
        BttCOS1 = New Button()
        BttTAN = New Button()
        BttTAN1 = New Button()
        BttSIN1 = New Button()
        BttRAD = New Button()
        BttGRAUS = New Button()
        BttCONTAGENS = New Button()
        BttLOG = New Button()
        BttSD = New Button()
        BttPERMUTACOES = New Button()
        BttAPAGAR = New Button()
        BttFATORIAL = New Button()
        SuspendLayout()
        ' 
        ' TxtBox
        ' 
        TxtBox.Location = New Point(134, 81)
        TxtBox.Multiline = True
        TxtBox.Name = "TxtBox"
        TxtBox.Size = New Size(230, 45)
        TxtBox.TabIndex = 0
        TxtBox.Text = "0"
        TxtBox.TextAlign = HorizontalAlignment.Right
        ' 
        ' Btt1
        ' 
        Btt1.BackColor = Color.LavenderBlush
        Btt1.BackgroundImage = CType(resources.GetObject("Btt1.BackgroundImage"), Image)
        Btt1.Location = New Point(171, 141)
        Btt1.Name = "Btt1"
        Btt1.Size = New Size(45, 49)
        Btt1.TabIndex = 1
        Btt1.Text = "1"
        Btt1.UseVisualStyleBackColor = False
        ' 
        ' Btt2
        ' 
        Btt2.BackColor = Color.LavenderBlush
        Btt2.BackgroundImage = CType(resources.GetObject("Btt2.BackgroundImage"), Image)
        Btt2.Location = New Point(224, 141)
        Btt2.Name = "Btt2"
        Btt2.Size = New Size(45, 49)
        Btt2.TabIndex = 2
        Btt2.Text = "2"
        Btt2.UseVisualStyleBackColor = False
        ' 
        ' Btt5
        ' 
        Btt5.BackColor = Color.LavenderBlush
        Btt5.Location = New Point(224, 205)
        Btt5.Name = "Btt5"
        Btt5.Size = New Size(45, 49)
        Btt5.TabIndex = 3
        Btt5.Text = "5"
        Btt5.UseVisualStyleBackColor = False
        ' 
        ' Btt4
        ' 
        Btt4.BackColor = Color.LavenderBlush
        Btt4.Location = New Point(171, 205)
        Btt4.Name = "Btt4"
        Btt4.Size = New Size(45, 49)
        Btt4.TabIndex = 4
        Btt4.Text = "4"
        Btt4.UseVisualStyleBackColor = False
        ' 
        ' Btt3
        ' 
        Btt3.BackColor = Color.LavenderBlush
        Btt3.Location = New Point(275, 141)
        Btt3.Name = "Btt3"
        Btt3.Size = New Size(45, 49)
        Btt3.TabIndex = 5
        Btt3.Text = "3"
        Btt3.UseVisualStyleBackColor = False
        ' 
        ' Btt8
        ' 
        Btt8.BackColor = Color.LavenderBlush
        Btt8.Location = New Point(224, 269)
        Btt8.Name = "Btt8"
        Btt8.Size = New Size(45, 49)
        Btt8.TabIndex = 6
        Btt8.Text = "8"
        Btt8.UseVisualStyleBackColor = False
        ' 
        ' Btt6
        ' 
        Btt6.BackColor = Color.LavenderBlush
        Btt6.Location = New Point(275, 205)
        Btt6.Name = "Btt6"
        Btt6.Size = New Size(45, 49)
        Btt6.TabIndex = 7
        Btt6.Text = "6"
        Btt6.UseVisualStyleBackColor = False
        ' 
        ' Btt0
        ' 
        Btt0.BackColor = Color.LavenderBlush
        Btt0.Location = New Point(224, 331)
        Btt0.Name = "Btt0"
        Btt0.Size = New Size(45, 42)
        Btt0.TabIndex = 0
        Btt0.Text = "0"
        Btt0.UseVisualStyleBackColor = False
        ' 
        ' Btt9
        ' 
        Btt9.BackColor = Color.LavenderBlush
        Btt9.Location = New Point(275, 269)
        Btt9.Name = "Btt9"
        Btt9.Size = New Size(45, 49)
        Btt9.TabIndex = 9
        Btt9.Text = "9"
        Btt9.UseVisualStyleBackColor = False
        ' 
        ' Btt7
        ' 
        Btt7.BackColor = Color.LavenderBlush
        Btt7.Location = New Point(171, 269)
        Btt7.Name = "Btt7"
        Btt7.Size = New Size(45, 49)
        Btt7.TabIndex = 10
        Btt7.Text = "7"
        Btt7.UseVisualStyleBackColor = False
        ' 
        ' BttVEZES
        ' 
        BttVEZES.BackColor = Color.Wheat
        BttVEZES.Location = New Point(470, 132)
        BttVEZES.Name = "BttVEZES"
        BttVEZES.Size = New Size(61, 42)
        BttVEZES.TabIndex = 11
        BttVEZES.Text = "X"
        BttVEZES.UseVisualStyleBackColor = False
        ' 
        ' BttIGUAL
        ' 
        BttIGUAL.BackColor = Color.Wheat
        BttIGUAL.Location = New Point(403, 81)
        BttIGUAL.Name = "BttIGUAL"
        BttIGUAL.Size = New Size(61, 42)
        BttIGUAL.TabIndex = 12
        BttIGUAL.Text = "="
        BttIGUAL.UseVisualStyleBackColor = False
        ' 
        ' BttMAIS
        ' 
        BttMAIS.BackColor = Color.Wheat
        BttMAIS.Location = New Point(403, 132)
        BttMAIS.Name = "BttMAIS"
        BttMAIS.Size = New Size(61, 42)
        BttMAIS.TabIndex = 13
        BttMAIS.Text = "+"
        BttMAIS.UseVisualStyleBackColor = False
        ' 
        ' BttSQR
        ' 
        BttSQR.BackColor = Color.Wheat
        BttSQR.Location = New Point(536, 81)
        BttSQR.Name = "BttSQR"
        BttSQR.Size = New Size(61, 45)
        BttSQR.TabIndex = 14
        BttSQR.Text = "√"
        BttSQR.UseVisualStyleBackColor = False
        ' 
        ' BttMENOS
        ' 
        BttMENOS.BackColor = Color.Wheat
        BttMENOS.Location = New Point(403, 184)
        BttMENOS.Name = "BttMENOS"
        BttMENOS.Size = New Size(61, 42)
        BttMENOS.TabIndex = 15
        BttMENOS.Text = "-"
        BttMENOS.UseVisualStyleBackColor = False
        ' 
        ' BttDIVIDIR
        ' 
        BttDIVIDIR.BackColor = Color.Wheat
        BttDIVIDIR.Location = New Point(470, 184)
        BttDIVIDIR.Name = "BttDIVIDIR"
        BttDIVIDIR.Size = New Size(61, 42)
        BttDIVIDIR.TabIndex = 16
        BttDIVIDIR.Text = ":"
        BttDIVIDIR.UseVisualStyleBackColor = False
        ' 
        ' BttC
        ' 
        BttC.BackColor = Color.LavenderBlush
        BttC.Location = New Point(171, 331)
        BttC.Name = "BttC"
        BttC.Size = New Size(45, 42)
        BttC.TabIndex = 17
        BttC.Text = "c"
        BttC.UseVisualStyleBackColor = False
        ' 
        ' BttPONTO
        ' 
        BttPONTO.BackColor = Color.LavenderBlush
        BttPONTO.Location = New Point(275, 331)
        BttPONTO.Name = "BttPONTO"
        BttPONTO.Size = New Size(45, 42)
        BttPONTO.TabIndex = 18
        BttPONTO.Text = ","
        BttPONTO.UseVisualStyleBackColor = False
        ' 
        ' BttELEVADO
        ' 
        BttELEVADO.BackColor = Color.Wheat
        BttELEVADO.Location = New Point(470, 288)
        BttELEVADO.Name = "BttELEVADO"
        BttELEVADO.Size = New Size(61, 42)
        BttELEVADO.TabIndex = 24
        BttELEVADO.Text = "e^"
        BttELEVADO.UseVisualStyleBackColor = False
        ' 
        ' BttSIN
        ' 
        BttSIN.BackColor = Color.Wheat
        BttSIN.Location = New Point(403, 340)
        BttSIN.Name = "BttSIN"
        BttSIN.Size = New Size(61, 42)
        BttSIN.TabIndex = 23
        BttSIN.Text = "sin"
        BttSIN.UseVisualStyleBackColor = False
        ' 
        ' BttCOS
        ' 
        BttCOS.BackColor = Color.Wheat
        BttCOS.Location = New Point(470, 340)
        BttCOS.Name = "BttCOS"
        BttCOS.Size = New Size(61, 42)
        BttCOS.TabIndex = 22
        BttCOS.Text = "cos"
        BttCOS.UseVisualStyleBackColor = False
        ' 
        ' BttPI
        ' 
        BttPI.BackColor = Color.Wheat
        BttPI.Location = New Point(403, 288)
        BttPI.Name = "BttPI"
        BttPI.Size = New Size(61, 42)
        BttPI.TabIndex = 21
        BttPI.Text = "π"
        BttPI.UseVisualStyleBackColor = False
        ' 
        ' BttFR
        ' 
        BttFR.BackColor = Color.Wheat
        BttFR.Location = New Point(403, 237)
        BttFR.Name = "BttFR"
        BttFR.Size = New Size(61, 42)
        BttFR.TabIndex = 20
        BttFR.Text = "FR"
        BttFR.UseVisualStyleBackColor = False
        ' 
        ' BttSQRELE
        ' 
        BttSQRELE.BackColor = Color.Wheat
        BttSQRELE.Location = New Point(470, 237)
        BttSQRELE.Name = "BttSQRELE"
        BttSQRELE.Size = New Size(61, 42)
        BttSQRELE.TabIndex = 19
        BttSQRELE.Text = "√^x"
        BttSQRELE.UseVisualStyleBackColor = False
        ' 
        ' BttCOS1
        ' 
        BttCOS1.BackColor = Color.Wheat
        BttCOS1.Location = New Point(604, 288)
        BttCOS1.Name = "BttCOS1"
        BttCOS1.Size = New Size(67, 42)
        BttCOS1.TabIndex = 36
        BttCOS1.Text = "cos^-1"
        BttCOS1.UseVisualStyleBackColor = False
        ' 
        ' BttTAN
        ' 
        BttTAN.BackColor = Color.Wheat
        BttTAN.Location = New Point(537, 340)
        BttTAN.Name = "BttTAN"
        BttTAN.Size = New Size(60, 42)
        BttTAN.TabIndex = 35
        BttTAN.Text = "tan"
        BttTAN.UseVisualStyleBackColor = False
        ' 
        ' BttTAN1
        ' 
        BttTAN1.BackColor = Color.Wheat
        BttTAN1.Location = New Point(604, 237)
        BttTAN1.Name = "BttTAN1"
        BttTAN1.Size = New Size(67, 42)
        BttTAN1.TabIndex = 34
        BttTAN1.Text = "tan^-1"
        BttTAN1.UseVisualStyleBackColor = False
        ' 
        ' BttSIN1
        ' 
        BttSIN1.BackColor = Color.Wheat
        BttSIN1.Location = New Point(537, 288)
        BttSIN1.Name = "BttSIN1"
        BttSIN1.Size = New Size(60, 42)
        BttSIN1.TabIndex = 33
        BttSIN1.Text = "sin^-1"
        BttSIN1.UseVisualStyleBackColor = False
        ' 
        ' BttRAD
        ' 
        BttRAD.BackColor = Color.Wheat
        BttRAD.Location = New Point(537, 184)
        BttRAD.Name = "BttRAD"
        BttRAD.Size = New Size(60, 42)
        BttRAD.TabIndex = 32
        BttRAD.Text = "Rad "
        BttRAD.UseVisualStyleBackColor = False
        ' 
        ' BttGRAUS
        ' 
        BttGRAUS.BackColor = Color.Wheat
        BttGRAUS.Location = New Point(537, 237)
        BttGRAUS.Name = "BttGRAUS"
        BttGRAUS.Size = New Size(60, 42)
        BttGRAUS.TabIndex = 31
        BttGRAUS.Text = "Graus"
        BttGRAUS.UseVisualStyleBackColor = False
        ' 
        ' BttCONTAGENS
        ' 
        BttCONTAGENS.BackColor = Color.Wheat
        BttCONTAGENS.Location = New Point(604, 132)
        BttCONTAGENS.Name = "BttCONTAGENS"
        BttCONTAGENS.Size = New Size(67, 42)
        BttCONTAGENS.TabIndex = 30
        BttCONTAGENS.Text = "nCp"
        BttCONTAGENS.UseVisualStyleBackColor = False
        ' 
        ' BttLOG
        ' 
        BttLOG.BackColor = Color.Wheat
        BttLOG.Location = New Point(537, 132)
        BttLOG.Name = "BttLOG"
        BttLOG.Size = New Size(60, 42)
        BttLOG.TabIndex = 29
        BttLOG.Text = "log"
        BttLOG.UseVisualStyleBackColor = False
        ' 
        ' BttSD
        ' 
        BttSD.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(192))
        BttSD.Location = New Point(604, 340)
        BttSD.Name = "BttSD"
        BttSD.Size = New Size(67, 42)
        BttSD.TabIndex = 28
        BttSD.Text = "SAIR"
        BttSD.UseVisualStyleBackColor = False
        ' 
        ' BttPERMUTACOES
        ' 
        BttPERMUTACOES.BackColor = Color.Wheat
        BttPERMUTACOES.Location = New Point(604, 184)
        BttPERMUTACOES.Name = "BttPERMUTACOES"
        BttPERMUTACOES.Size = New Size(67, 42)
        BttPERMUTACOES.TabIndex = 27
        BttPERMUTACOES.Text = "nPc"
        BttPERMUTACOES.UseVisualStyleBackColor = False
        ' 
        ' BttAPAGAR
        ' 
        BttAPAGAR.BackColor = Color.Wheat
        BttAPAGAR.Location = New Point(471, 81)
        BttAPAGAR.Name = "BttAPAGAR"
        BttAPAGAR.Size = New Size(60, 42)
        BttAPAGAR.TabIndex = 26
        BttAPAGAR.Text = "⌫"
        BttAPAGAR.UseVisualStyleBackColor = False
        ' 
        ' BttFATORIAL
        ' 
        BttFATORIAL.BackColor = Color.Wheat
        BttFATORIAL.Location = New Point(604, 81)
        BttFATORIAL.Name = "BttFATORIAL"
        BttFATORIAL.Size = New Size(67, 42)
        BttFATORIAL.TabIndex = 25
        BttFATORIAL.Text = "n!"
        BttFATORIAL.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(800, 450)
        Controls.Add(BttCOS1)
        Controls.Add(BttTAN)
        Controls.Add(BttTAN1)
        Controls.Add(BttSIN1)
        Controls.Add(BttRAD)
        Controls.Add(BttGRAUS)
        Controls.Add(BttCONTAGENS)
        Controls.Add(BttLOG)
        Controls.Add(BttSD)
        Controls.Add(BttPERMUTACOES)
        Controls.Add(BttAPAGAR)
        Controls.Add(BttFATORIAL)
        Controls.Add(BttELEVADO)
        Controls.Add(BttSIN)
        Controls.Add(BttCOS)
        Controls.Add(BttPI)
        Controls.Add(BttFR)
        Controls.Add(BttSQRELE)
        Controls.Add(BttPONTO)
        Controls.Add(BttC)
        Controls.Add(BttDIVIDIR)
        Controls.Add(BttMENOS)
        Controls.Add(BttSQR)
        Controls.Add(BttMAIS)
        Controls.Add(BttIGUAL)
        Controls.Add(BttVEZES)
        Controls.Add(Btt7)
        Controls.Add(Btt9)
        Controls.Add(Btt0)
        Controls.Add(Btt6)
        Controls.Add(Btt8)
        Controls.Add(Btt3)
        Controls.Add(Btt4)
        Controls.Add(Btt5)
        Controls.Add(Btt2)
        Controls.Add(Btt1)
        Controls.Add(TxtBox)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        KeyPreview = True
        Name = "Form1"
        Text = "Calculadora "
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TxtBox As TextBox
    Friend WithEvents Btt1 As Button
    Friend WithEvents Btt2 As Button
    Friend WithEvents Btt5 As Button
    Friend WithEvents Btt4 As Button
    Friend WithEvents Btt3 As Button
    Friend WithEvents Btt8 As Button
    Friend WithEvents Btt6 As Button
    Friend WithEvents Btt0 As Button
    Friend WithEvents Btt9 As Button
    Friend WithEvents Btt7 As Button
    Friend WithEvents BttVEZES As Button
    Friend WithEvents BttIGUAL As Button
    Friend WithEvents BttMAIS As Button
    Friend WithEvents BttSQR As Button
    Friend WithEvents BttMENOS As Button
    Friend WithEvents BttDIVIDIR As Button
    Friend WithEvents BttC As Button
    Friend WithEvents BttPONTO As Button
    Friend WithEvents BttELEVADO As Button
    Friend WithEvents BttSIN As Button
    Friend WithEvents BttCOS As Button
    Friend WithEvents BttPI As Button
    Friend WithEvents BttFR As Button
    Friend WithEvents BttSQRELE As Button
    Friend WithEvents BttCOS1 As Button
    Friend WithEvents BttTAN As Button
    Friend WithEvents BttTAN1 As Button
    Friend WithEvents BttSIN1 As Button
    Friend WithEvents BttRAD As Button
    Friend WithEvents BttGRAUS As Button
    Friend WithEvents BttCONTAGENS As Button
    Friend WithEvents BttLOG As Button
    Friend WithEvents BttSD As Button
    Friend WithEvents BttPERMUTACOES As Button
    Friend WithEvents BttAPAGAR As Button
    Friend WithEvents BttFATORIAL As Button

End Class
